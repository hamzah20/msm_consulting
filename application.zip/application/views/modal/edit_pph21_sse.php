 <div class="modal fade" id="editModalPPH21SSE" tabindex="-1" aria-labelledby="editPPH21SSE" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <form class="needs-validation" id="formAddSSE" method="POST" novalidate action="<?= base_url('PPH/Pph21/edit_sse'); ?>">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="editPPH21SSE">SSE - PPH 21</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body ModalEditSSE"> 
              
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary btn-sm">Save</button>
              <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
            </div>
          </div>
        </form>
      </div>
    </div>