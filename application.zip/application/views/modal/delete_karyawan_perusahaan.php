  	<div class="modal fade" id="deleteKaryawanPerusahaan" tabindex="-1" aria-labelledby="deleteKaryawanPerusahaan" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="deleteKaryawanPerusahaan">Hapus Data Karyawan</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	        APAKAH DATA INGIN DIHAPUS?
	      </div>
	      <div class="modal-footer">
	      	<button type="button" class="btn btn-danger" href="#">Hapus</button>
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
	      </div>
	    </div>
	  </div>
	</div>