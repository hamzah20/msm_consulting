  	<div class="modal fade" id="lihatDokumenBukti" tabindex="-1" aria-labelledby="lihatDokumenBukti" aria-hidden="true">
  		<div class="modal-dialog">
  			<div class="modal-content">
  				<form class="needs-validation" id="formAddCompany" action="<?= base_url('General/Client/addCompany'); ?>" method="POST" novalidate>
  					<div class="modal-header">
  						<h5 class="modal-title" id="lihatDokumenBukti">Tampilan Dokumen</h5>
  						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
  							<span aria-hidden="true">&times;</span>
  						</button>
  					</div>
  					<div class="modal-body">
  						<img src="<?php echo base_url('assets/images/dokumen_bukti/no-image.png') ?>">

  					</div> 
  				</form>
  			</div>
  		</div>
  	</div>